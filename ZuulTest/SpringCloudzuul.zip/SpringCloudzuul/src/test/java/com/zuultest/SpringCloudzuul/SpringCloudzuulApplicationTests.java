package com.zuultest.SpringCloudzuul;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudzuulApplicationTests {

	@Test
	void contextLoads() {
	}

}
