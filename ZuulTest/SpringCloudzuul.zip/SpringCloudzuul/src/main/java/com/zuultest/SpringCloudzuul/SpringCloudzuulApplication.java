package com.zuultest.SpringCloudzuul;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCloudzuulApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCloudzuulApplication.class, args);
	}

}
